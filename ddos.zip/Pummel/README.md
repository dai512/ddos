```
██████╗ ██╗   ██╗███╗   ███╗███╗   ███╗███████╗██╗         
██╔══██╗██║   ██║████╗ ████║████╗ ████║██╔════╝██║         
██████╔╝██║   ██║██╔████╔██║██╔████╔██║█████╗  ██║         
██╔═══╝ ██║   ██║██║╚██╔╝██║██║╚██╔╝██║██╔══╝  ██║         
██║     ╚██████╔╝██║ ╚═╝ ██║██║ ╚═╝ ██║███████╗███████╗    
╚═╝      ╚═════╝ ╚═╝     ╚═╝╚═╝     ╚═╝╚══════╝╚══════╝  
```
![](https://img.shields.io/badge/Version-1.2.8-brightgreen.svg) ![](https://img.shields.io/badge/license-MIT-blue.svg)

Update:
- [x] Prevent Attacking .edu or .gov website

Func:

- [x] HTTP-Flooding 
- [x] HTTPS-Flooding 
- [x] Semiauto-Get Socks5 Proxies
- [x] Socks5 Proxies Checker
- [x] GET/HEAD Mode
- [x] User-friendly

![test](https://user-images.githubusercontent.com/63648976/79683896-e7c25c80-825f-11ea-9d31-09e473cb838c.gif)

Install
---
```
pip3 install requests pysocks
git clone https://github.com/HC133/Pummel.git
cd Pummel
```
Usage
---
```
python3 pummel.py
```
